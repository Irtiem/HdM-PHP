        <!--================ start footer Area  =================-->	
        <footer class="footer-area p_120">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3  col-md-6 col-sm-6">
                        <div class="single-footer-widget ab_wd">
                            <h6 class="footer_title">Información</h6>
                            <p>Politica de Cookies</p>
							<p>Aviso Legal</p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6">
                        <div class="single-footer-widget contact_wd">
                            <h6 class="footer_title">Contacto</h6>
                            <p>historiasdemazmorra@hotmail.com</p>		
                        </div>
                    </div>							
                    <div class="col-lg-5 col-md-6 col-sm-6 offset-lg-1">
                        <div class="single-footer-widget">
                            <h6 class="footer_title">BOLETÍN</h6>
                            <p>Solo enviamos correos informativos sobre las aventuras de rol.</p>		
                        </div>
                    </div>
                </div>
                <div class="row footer-bottom d-flex justify-content-between align-items-center">
                    <p class="col-lg-8 col-md-8 footer-text m-0"></p>
                    <div class="col-lg-4 col-md-4 footer-social">
						<div id="parrafo"> </div>
                        <a href="#"><i class="fa fa-facebook"></i></a>
                        <a href="#"><i class="fa fa-twitter"></i></a>
                    </div>
                </div>
            </div>
        </footer>
		<!--================ End footer Area  =================-->
        
        
        
        

        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="js/popper.js"></script>
		<script src="js/bootstrap.min.js"></script>
    </body>
</html>