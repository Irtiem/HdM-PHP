<?php
	include ("cabecera.php");
	
	$pagina="jugar";
	if(isset($_GET['p']))
		$pagina= $_GET['p'];	
?>

        
	<h1>FORO</h1>
<?php
	include ("pie.php");
?>